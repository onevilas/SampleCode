package com.connected.harman.todoapp.callback;

/**
 * Created by Vilas on 2/20/2016.
 *
 * Interface to handle fragment navigation.
 */
public interface OnNavigationListener {

    public void onBackToParent();
}
